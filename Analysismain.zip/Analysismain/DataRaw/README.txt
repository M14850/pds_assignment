1. The "diabetes.csv" file contains data for 768 patients. This dataset contains 8 attributes (eg, Blood Pressure, Blood Pressure, Skin Thickness, Insulin, BMI, Glycemic Function, and Age) and 1 response variable (value). The response variable has a binary value (1 result means diabetes, 0 means no diabetes) We treat all data publicly for analysis

a) .
First, we create a sample of size 25 from the population and find the mean and maximum sweet spot of that sample and compare the statistics with the population statistics to see the difference between the same. Create bar charts and pie charts to visualize comparisons.


b) Then find the 98th percentile of the sample and population BMI and compare the results using tables (bar and line charts)

c) Using Bootstrap (change = Really), generate 500 samples from the population (150 Observations) sample per sample) and find the mean, standard deviation, and percentage of blood pressure and compare statistics of difference with each sample and generate graphs (bar charts and graphs) for comparison.
All results are saved in the received file.