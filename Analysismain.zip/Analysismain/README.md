# diabetesAnalysis
examine the diabetis dataset

Created By 
Sri Aditya kilari
16330039

1. RawData is in RawData folder
2. CleanData in CleanData folder
3. Results are in Results folder segregated by (A,B,C) according to the question given
4. source code under src folder
